package com.haibernet.query;
import java.util.Iterator;  
import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;



public class App  
{
    public static void main( String[] args )
    {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        
        Employee1 emp = new Employee1(); 
        /*emp.setName("Jayesh");
        emp.setSalary(20000);
        emp.setJob("Developer");
        session.save(emp);*/
        
       /* tx.commit();
        session.close(); */
        System.out.println("Add Information Successfully");

        TypedQuery query = session.getNamedQuery("findEmployee1ByName");
        query.setParameter("name","Krushna");
        
        List<Employee1> employees=query.getResultList();
    	Iterator<Employee1> itr=employees.iterator();
    	while(itr.hasNext())
    	{
    		Employee1 e=itr.next();
    		System.out.println(e);
    	}
    	 tx.commit();
         session.close();

        
        
        
    }
}
