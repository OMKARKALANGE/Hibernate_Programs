package com.anudip.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.Transaction;


public class App 
{
    public static void main( String[] args )
    {
    	Session session =HibernateUtil.getSessionFactory().openSession();
    	
    	//student Create  - C
    	Student st =new Student();
    	st.setName("Jayesh");
    	st.setAddress("Jalgaon");
    	st.setEmail("Jay@gmail.com");
    	st.setClgname("NM University"); 
    	
    	Transaction tx=session.beginTransaction(); 
    	tx.commit();
    	
    	System.out.println("Student added.....");
    	session.save(st);
    	
    	session.close();
    	
    }
}
